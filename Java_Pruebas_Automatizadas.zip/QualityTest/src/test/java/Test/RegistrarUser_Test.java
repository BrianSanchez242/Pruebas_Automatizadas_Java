package Test;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import Pages.HomePage;
import Pages.PagoPage;
import Pages.RegistrarPage;
import junit.framework.Assert;
import net.bytebuddy.jar.asm.Handle;

public class RegistrarUser_Test {

	private WebDriver driver;
	String expectedResult = null;
	String actualResult = null;
	HomePage objHome;
	RegistrarPage objRegistrar;
	PagoPage ObjectPago;
	
	
	
	@Before
	public void setUp() throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "./src/test/resources/chromedriver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		
		
		
		driver.get("http://automationpractice.com/index.php");
	}

	@After
	public void tearDown() throws Exception {
		
		driver.close();
	}

	@Test
	public void test() {
		
		
		
		objHome = new HomePage(driver);
//		objHome.ClickLinkLogin();
		objHome.CrerunaCuenta("brian15@gmail.com");
				
//		expectedResult = "Crear una Cuenta: New Experience";
//		actualResult = objHome.getHomePageTitle();
		
//		Assert.assertEquals(expectedResult, actualResult);
//		objHome.BtnCrearCta();
		  
		
		
		objRegistrar = new RegistrarPage(driver);
		objRegistrar.TuInformacionUsuario("Briann", "Sanchez Cort", "12345", "Miraflowers", "Lima", "Arizona",
				"00099", "999999999");
		
//		objRegistrar.BtnCrear();

	}
	

	
	


}
