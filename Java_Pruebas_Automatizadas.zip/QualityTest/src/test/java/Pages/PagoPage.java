package Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.internal.WebElementToJsonConverter;

public class PagoPage {

	
	private WebDriver driver;
	
	By LnkLogin = By.linkText("Sign in");
	By TxtEmail = By.id("email");
	By TxtPassword = By.id("passwd");
	By BtnEntrar = By.xpath("//button[@id='SubmitLogin' and @name='SubmitLogin']");
	
	By IconHome = By.xpath("//a[@class='home' and @href='http://automationpractice.com/']");
	
	By BtnDatos = By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a");
	By BtnHistoria= By.xpath("//*[@id=\"center_column\"]/div/div[1]/ul/li[1]/a");
	
	By NumCom = By.xpath("//*[@id=\"order-list\"]/tbody/tr/td[1]/a");
	By Reorde = By.xpath("//*[@id=\"submitReorder\"]/a");
	By Proceedcheck = By.xpath("//*[@id=\"center_column\"]/p[2]/a[1]");
	
	
	
//	By BtnCarrito1 = By.cssSelector("#homefeatured > li.ajax_block_product.col-xs-12.col-sm-4.col-md-3.first-in-line.first-item-of-tablet-line.first-item-of-mobile-line > div > div.right-block > div.button-container > a.button.ajax_add_to_cart_button.btn.btn-default\r\n");
//	By BtnCarrito2 = By.xpath("//*[@id=\"homefeatured\"]/li[2]/div/div[1]/div/a[1]/img");
//	By BtnCarrito3 = By.xpath("//*[@id=\"homefeatured\"]/li[3]/div/div[1]/div/a[1]/img");
	
//	By BtnAgregarCar = By.xpath("//*[@id=\"add_to_cart\"]");
	
	
//	By BtnSegComprando = By.xpath("///*[@id=\"add_to_cart\"]/button");
	
	
	//*[@id="ordermsg"]/textarea
	
	By TxtComent = By.xpath("//textarea[@name='message']"); 
	By BtnNextCaj2 = By.xpath("//*[@id=\"center_column\"]/form/p/button");
	
	
	By CheckBox = By.id("cgv");
	
	
	By BtnNext3CaJ3 = By.xpath("//*[@id=\"form\"]/p/button");
	By LinkPagoTranf = By.xpath("//*[@id=\"HOOK_PAYMENT\"]/div[1]/div/p/a");
	By BtnConfirOrden = By.xpath("//*[@id=\"cart_navigation\"]/button");
	
	
			
	public PagoPage(WebDriver driver) {
		
		this.driver = driver;
	}
	

	public void ClickBtnNumCom() {
		
		driver.findElement(NumCom).click();
	}
	
	public void ClickReorde() {
		driver.findElement(Reorde).click();
		
	}
	
	public void ClickProceedcheck() {
		driver.findElement(Proceedcheck).click();
		
	}
	
	
	
	
	
	public void ClickBtnDatos() {
		driver.findElement(BtnDatos).click();
		
	}
	
	public void ClickBtnHistoria() {
		driver.findElement(BtnHistoria).click();
		
	}
	
		
	
	public void ClickLinkLogin() {
		driver.findElement(LnkLogin).click();
		
		}
	
	
	public void setTxtEmail(String strTxtEmail) {
		driver.findElement(TxtEmail).sendKeys(strTxtEmail);
		
	}
	
	public void setTxtPassword(String strTxtPassword) {
		driver.findElement(TxtPassword).sendKeys(strTxtPassword);
		
	}
	
	public void BtnEntrar() {
		driver.findElement(BtnEntrar).click();
		
	}
	
	public void BtnIconHome() {
		driver.findElement(IconHome).click();
		
	}
	
	public void BtnCarrito1() {
//		driver.findElement(BtnCarrito1).click();
		
	}
	
	public void BtnAgregarcar() {
//		driver.findElement(BtnAgregarCar).click();
		
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		
		
	}
	
	public void BtnCarrito2() {
//		driver.findElement(BtnCarrito2).click();
				
	}
	
	public void BtnCarrito3() {
//		driver.findElement(BtnCarrito3).click();
				
	}
	
	
	public void BtnSegComprando() {
		
//		driver.findElement(BtnSegComprando).click();

				
	}
	
//	public void BtnProPago() {
//		driver.findElement(BtnProPago).click();
				
//	}
	
//	public void BtnNextCaj() {
//		driver.findElement(BtnNextCaj).click();
				
//	}

	public void setTxtComent(String strTxtComent) {
		driver.findElement(TxtComent).sendKeys(strTxtComent);
				
	}
	
	
	public void BtnNextCaj2() {
		driver.findElement(BtnNextCaj2).click();
				
	}
	
	public void BtnCheckBox() {
		driver.findElement(CheckBox).click();
				
	}
	
	public void BtnNext3CaJ3() {
		driver.findElement(BtnNext3CaJ3).click();
				
	}
	
	public void selectLinkPagoTranf() {
		driver.findElement(LinkPagoTranf).click();
				
	}
	
	public void BtnConfirOrden() {
		driver.findElement(BtnConfirOrden).click();
				
	}
	
	public void IngresarUsuario(String strTxtEmail, String strTxtPassword) {
		
		this.setTxtEmail(strTxtEmail);
		this.setTxtPassword(strTxtPassword);
		this.BtnEntrar();
	}
	
	
	public void ComprandPago(String strTxtComent) {
		

		this.BtnIconHome();
		this.ClickBtnDatos();
		this.ClickBtnHistoria();
		this.ClickBtnNumCom();
		this.ClickReorde();
		this.ClickProceedcheck();
//		this.BtnCarrito1();
//		this.BtnAgregarcar();
//		this.BtnSegComprando();
//		this.BtnCarrito2();
//		this.BtnSegComprando();
//		this.BtnCarrito3();
//		this.BtnProPago();
//		this.BtnNextCaj();
		this.setTxtComent(strTxtComent);
		this.BtnNextCaj2();
		this.BtnCheckBox();
		this.BtnNext3CaJ3();
		this.selectLinkPagoTranf();
		this.BtnConfirOrden();
		

		}
	
}
