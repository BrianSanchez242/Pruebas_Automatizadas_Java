package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class RegistrarPage {

	private WebDriver driver;
	
	By TxtNombre = By.xpath("//input[@id='customer_firstname']");
	By TxtApellido = By.id("customer_lastname");
	By TxtPassword = By.id("passwd");
	By TxtDir1 = By.id("address1");
	By TxtCiudad = By.id("city");
	By DdlEstado = By.id("id_state");
	By TxtCodPostal = By.name("postcode");
	By DdlPais = By.id("id_country");
	By TxtPhone = By.name("phone");
	By BtnCrear = By.xpath("//button[@type='submit' and @name='submitAccount']");
	
	public RegistrarPage(WebDriver driver) {
		this.driver = driver;
		
	}
	
	public void setNombre(String strTxtNombre) {
		driver.findElement(TxtNombre).sendKeys(strTxtNombre);
		
	}
	
	public void setApellido(String strTxtApellido) {
		driver.findElement(TxtApellido).sendKeys(strTxtApellido);
		
	}
	
	public void setPassword(String strTxtPassword) {
		driver.findElement(TxtPassword).sendKeys(strTxtPassword);
		
	}
	
	public void setDir1(String strTxtDir1) {
		driver.findElement(TxtDir1).sendKeys(strTxtDir1);
		
	}
	
	public void setCiudad(String strTxtCiudad) {
		driver.findElement(TxtCiudad).sendKeys(strTxtCiudad);
		
	}
	
	public void SelectEstado(String strDdlEstado) {
		new Select(driver.findElement(DdlEstado)).selectByVisibleText(strDdlEstado);		
		
		}
	
	public void setCodPostal(String strCodPostal) {
		driver.findElement(TxtCodPostal).sendKeys(strCodPostal);
		
	}
	
//	public void SelectPais(String strDdlPais) {
//		new Select(driver.findElement(DdlPais)).selectByVisibleText(strDdlPais);
		
//	}
	
	public void setPhone(String strTxtPhone) {
		driver.findElement(TxtPhone).sendKeys(strTxtPhone);
		
	}
	
	public void BtnCrear() {
		driver.findElement(BtnCrear).click();
		
	}
	
	//Navigation Model 
	public void TuInformacionUsuario(String strNombre, String strApellido, 
			String strPassword, String strDir1, String strCiudad,
			String strEstado, 
//			String strPais,
			String strCodPostal, String strPhone) {
		
		this.setNombre(strNombre);
		this.setApellido(strApellido);
		this.setPassword(strPassword);
		this.setDir1(strDir1);
		this.setCiudad(strCiudad);
		this.SelectEstado(strEstado);
		this.setCodPostal(strCodPostal);
//		this.SelectPais(strPais);
		this.setPhone(strPhone);
		this.BtnCrear();
		
		
		
	}
	
}
