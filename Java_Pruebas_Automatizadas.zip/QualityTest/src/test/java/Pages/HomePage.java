package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {

	private WebDriver driver;
	
	By LnkLogin = By.linkText("Sign in");
	By TxtIngresarCorreo = By.id("email_create");
	By BtnCrearCta = By.xpath("//button[@type='submit' and @id='SubmitCreate']");
//	By BtnCrearCta = By.
	
	
	public  HomePage(WebDriver driver) {
		this.driver	= driver;
		
	}
	
	public void ClickLinkLogin() {
		driver.findElement(LnkLogin).click();
		
		}
	
	public void setTxtIngresarCorreo(String strTxtIngresarCorreo) {
		driver.findElement(TxtIngresarCorreo).sendKeys(strTxtIngresarCorreo);
		
	}
	
	public void BtnCrearCta() {
		driver.findElement(BtnCrearCta).click();
	}
 
//	public String getHomePageTitle() {
//		return driver.getTitle();
		
//	}
	
	public void CrerunaCuenta(String strIngresarCorreo) {
		this.ClickLinkLogin();
		this.setTxtIngresarCorreo(strIngresarCorreo);
		this.BtnCrearCta();
		
	}
	
	
}
